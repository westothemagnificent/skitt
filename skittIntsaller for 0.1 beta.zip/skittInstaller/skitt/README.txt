The skitt interpeter was made by Weston Justice

Skitt 0.1

to install 

1. create a folder called "skitt" at C:\ then drag the google drive content in the drive

2. edit system environment vars to include C:\skitt

to make a skitt file add .skitt to the end of the file

to run do the command "skitt yourFile.skitt"

