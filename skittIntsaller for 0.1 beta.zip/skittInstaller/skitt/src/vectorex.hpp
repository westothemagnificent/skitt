#include "debugger.hpp"
#include<vector>
#include<functional>

class{
    public:
        template <typename T>
        void printVector(std::vector<T> vec){
            try{
                debugger.writeLine("(*)--------VECTOR----------", NOTES);
                for (size_t i = 0; i < vec.size(); i++)
                {
                    debugger.writeLine("<" + vec[i] + ">", NOTES);
                }
                debugger.writeLine("(*)--------VECTOR----------", NOTES);
            }
            catch(...){
                debugger.writeLine("(!!)-- vector could not be printed", FATALERRORS);
            }
        }
        template <typename T>
        void printVectorOfToken(std::vector<T> vec){
            try{
                debugger.writeLine("(*)--------VECTOR----------", NOTES);
                for (size_t i = 0; i < vec.size(); i++)
                {
                    debugger.writeLine("<" + vec[i].string + " id: " + vec[i].id + " type: " + vec[i].type + ">", NOTES);
                }
                debugger.writeLine("(*)--------VECTOR----------", NOTES);
            }
            catch(...){
                debugger.writeLine("(!!)-- vector could not be printed", FATALERRORS);
            }
        }


}vectorEX;