#include <vector>
#include <algorithm>
#include "vectorex.hpp"
#include "debugger.hpp"

#pragma once

// operators 

const std::string assessmentOperator = "=";

// key words

const std::string intKeyWord = "int";
const std::string floatKeyWord = "float";
const std::string doubleKeyWord = "double";

const std::string stringKeyWord = "string";
const std::string charKeyWord = "char";

const std::string boolKeyWord = "bool";

const std::string voidKeyWord = "void";

const std::vector<std::string> allKeyWords = {intKeyWord,floatKeyWord,doubleKeyWord, charKeyWord,stringKeyWord, boolKeyWord, voidKeyWord};

const std::vector<int> numbers = {0,1,2,3,4,5,6,7,8,9};


class token{
    private:
        
    public:
        std::string string;
        std::string id;
        std::string type;

        token(std::string str){
            string = str;
        }
};

std::vector<token> tokens = {};

int stringToInt(std::string str){
    try
    {
        return std::stoi(str);
    }
    catch(const std::exception& e)
    {
        return -1;
    }
    
}

class{

    public:

        void GetAllTokens(std::string inputProgram){

            int index = 0;
            int oldindex = 0;
            std::cout << inputProgram << "\n";
            debugger.writeLine("(*)-- tokeniser has started");
            const std::vector<char> temCharsTEM = {' ', ';', '=','(',')', '{', '}', '[', ']', ','};
            const std::vector<char> oneLineTokensTEM = {'=', '(', ')', '{', '}', '[', ']' ,','};

            bool inString = false;

            std::vector<char> temChars = temCharsTEM;
            std::vector<char> oneLineTokens = oneLineTokensTEM;

            for (int i = 0; i < inputProgram.size(); i++)
            {   
                if(inputProgram.at(i) == '\\'){
                    i++;
                    continue;
                }
                if(std::find(temChars.begin(), temChars.end(), inputProgram.at(i)) != temChars.end()){
                        index = i;
                        if(inputProgram.substr(oldindex, index-oldindex).size() > 0){
                            tokens.push_back(token(inputProgram.substr(oldindex, index-oldindex)));
                        }
                        oldindex = index+1;
                    }
                    if(std::find(oneLineTokens.begin(), oneLineTokens.end(), inputProgram.at(i)) != oneLineTokens.end()){
                        tokens.push_back(token(std::string(1,inputProgram.at(i))));
                    }

                    // other cases
                    if (inputProgram.at(i) == '"'){
                        if(inString == false){
                            temChars = {};
                            oneLineTokens = {};
                            inString = true;
                        }
                        else if(inString == true){
                            inString = false;
                            temChars = temCharsTEM;
                            oneLineTokens = oneLineTokensTEM;
                        }
                    }
            }
            
            vectorEX.printVectorOfToken(tokens);

        }

}tokeniser;

class{
    public:

    void start(){

        debugger.writeLine("(*)-- lexer has started", NOTES);

        token * currentToken = new token("NULL");
        for (int i = 0; i < tokens.size(); i++){
            currentToken = &tokens[i];
            if(currentToken->string == assessmentOperator){
                currentToken->type = "operator";
                currentToken->id = "assessment";
            }

            if(currentToken->string == intKeyWord){
                currentToken->type = "dataType";
                currentToken->id = "int";
            }
            if(currentToken->string == floatKeyWord){
                currentToken->type = "dataType";
                currentToken->id = "float";
            }
            if(currentToken->string == doubleKeyWord){
                currentToken->type = "dataType";
                currentToken->id = "double";
            }

            if(currentToken->string == charKeyWord){
                currentToken->type = "dataType";
                currentToken->id = "char";
            }
            if(currentToken->string == stringKeyWord){
                currentToken->type = "dataType";
                currentToken->id = "string";
            }

            if(currentToken->string == boolKeyWord){
                currentToken->type = "dataType";
                currentToken->id = "bool";
            }

            if(currentToken->string == voidKeyWord){
                currentToken->type = "dataType";
                currentToken->id = "void";
            }

            if(std::find(numbers.begin(), numbers.end(), stringToInt(currentToken->string)) != numbers.end()){
                currentToken->type = "number";
            }
        }
        for (int i = 0; i < tokens.size(); i++){
            currentToken = &tokens[i];
    

        }


        vectorEX.printVectorOfToken(tokens);
    }
    

}lexer;
