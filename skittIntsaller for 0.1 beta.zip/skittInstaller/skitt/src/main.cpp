#include "debugger.hpp"
#include "interpeter.hpp"
#include <filesystem>
#include <iostream>
#include <fstream>
#include <sstream>
#include <string>


std::string program;


std::fstream file;


const char * installDir = "C:\\skitt";

std::string cacheFileDir = "program.txt";

int main(){


    std::filesystem::current_path(installDir);

    debugger.errorLevel = ALL;

    debugger.writeLine(std::filesystem::current_path(), NOTES);

    file.open(cacheFileDir); 
    
     if (file.is_open()) {

        std::stringstream ss;
        ss << file.rdbuf();
        

        program = ss.str();
        if (program.empty()) {
            debugger.writeLine("(!?)-- The file is empty", WARNINGS);
        } 
        program.erase(std::remove(program.begin(), program.end(), '\n'), program.cend());
        file.close();
    } 
    else {
        debugger.writeLine("(!!)-- Missing cache file", FATALERRORS);
        return 1;
    }
    
    std::cout << program << "\n";

    debugger.writeLine("(*)-- Starting...", NOTES);

    tokeniser.GetAllTokens(program);

    system("pause");
    //lexer.start();

    return 0;
}
