#include <iostream>
#include <string>

#define ALL 4
#define NONE -1
#define NOTES 0
#define WARNINGS 1
#define ERRORS 2
#define FATALERRORS 3

#pragma once

class {
    public:

        int errorLevel;

        template<typename T>
        void writeLine(T str){
            std::cout << str << "\n";
        }
        template<typename T>
        void write(T str){
            std::cout << str;
        }

        template<typename T>
        void writeLine(T str, int level){
            if(errorLevel == ALL || level < errorLevel){
                std::cout << str << "\n";
            }
        }
        template<typename T>
        void write(T str, int level){
            if(errorLevel == ALL || level < errorLevel){
                std::cout << str;
            }
        }


}debugger;