// #include "class.hpp"
#include <string>
#include <vector>
#include <functional>
#include <iostream>

#pragma once


class task{
    public:
        std::function<void()> update;
        std::function<void()> start;
        std::function<bool()> done;

        std::string name;

        bool hasRun;

        task(std::string inputName, std::function<void()> updateFunc, std::function<void()> startFunc, std::function<bool()> doneFunc){
            name = inputName;
            update = updateFunc;
            start = startFunc;
            done = doneFunc;
        }


};

class {
    public:

        std::vector<task*> tasks = {};

        void addTask(task* inputTask){
            tasks.push_back(inputTask);
        }

        void updateAll(){
            for(int i=0; i<tasks.size(); i++){
                if(tasks[i]->hasRun == true){
                    bool isDone = tasks[i]->done();
                    if(isDone == false){
                        tasks[i]->update();
                    }
                    else{
                        std::cout << "(*)-- Task " << tasks[i]->name << " is done" << "\n";
                        tasks.erase(tasks.begin() + i);
                    }
                }
                else{
                    tasks[i]->start();
                    tasks[i]->hasRun = true;
                }
            }
        }

        void stopTask(std::string name){

            for (int i=0; i < tasks.size(); i++){
                if(tasks[i]->name == name){
                    std::cout << "(*)-- Task " << tasks[i]->name << "was stoped" << "\n";
                    tasks.erase(tasks.begin() + i);
                }
            }
            
        }



}taskHandler;