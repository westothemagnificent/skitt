#include "SDLWINDOW.hpp"
#include <iostream>
#include <string>
#include <vector>
#include "Query.hpp"
#include <psapi.h>
#include <sys/stat.h>

WIN window;
SDL_Event event;
TTF_Font* Sans;


// class Paiza : public gameObject{
//     public:

//         bool grabed = false;

//         void click(int st, int t, button * self){
//             if(t == 1){
//                 grabed = true;
//             }
//             else{
//                 grabed = false;
//             }
//         }
        
//         button paizaButton = button([this](int st, int t, button * self){click(st, t, self);}, trect(0,0,50,50), trect(0,0,100,100), "paiza", "food", 2, gAssets.apple);

//         void start(){
//             gameObjectRec = trect(200,200,0,0);
//             bindRec(&paizaButton.buttonRec);
//             bindRec(&paizaButton.buttonSprite.sprite_rec);
//         }

//         void update(){
//             tickAllBoundRecs();
//             if(grabed){
//                 // paizaButton.buttonRec.x = window.mouseX;
//                 // paizaButton.buttonRec.y = window.mouseY;
//                 // paizaButton.buttonSprite.sprite_rec.y = window.mouseY;
//                 // paizaButton.buttonSprite.sprite_rec.x = window.mouseX;
//                 gameObjectRec.x = window.mouseX;
//                 gameObjectRec.y = window.mouseY;
//             }
//         }

//         Paiza(){
//             name = "paiza";
//             pushGameObject(&window.gameObjectPointers);
//             push(&window.scriptPointers);
//             paizaButton.push(&window.buttonPointers, &window.spritePointers);
//         }
// };

class leakText : public gameObject{
    public:

        text sprite = text(trect(0,0,700,100), "warringText", "text", 1, "there is a mermoy leak in this program",  {255,255,255}, Sans, window.ren);

    
        void start(){
            bindRec(&sprite.sprite_rec);
            gameObjectRec = trect(window.CENTERX, window.CENTERY,0,0);
        }

        void update(){
            tickAllBoundRecs();
        }

        leakText(){
            push(&window.scriptPointers);
            sprite.push(&window.textPointers);
        }
};

class installDirText : public gameObject{
    public:

        text sprite = text(trect(0,0,700,100), "installDirText", "text", 1, "install dir C:\\skitt",  {255,255,255}, Sans, window.ren);

    
        void start(){
            bindRec(&sprite.sprite_rec);
            gameObjectRec = trect(window.CENTERX-1000, window.CENTERY,0,0);
        }

        void update(){
            tickAllBoundRecs();
        }

        installDirText(){
            push(&window.scriptPointers);
            sprite.push(&window.textPointers);
        }
};

class skittInstalledText : public gameObject{
    public:

        text sprite = text(trect(0,0,700,100), "installedSkittText", "text", 1, "skitt has been installed",  {255,255,255}, Sans, window.ren);

    
        void start(){
            bindRec(&sprite.sprite_rec);
            gameObjectRec = trect(window.CENTERX-1000, window.CENTERY+100,0,0);
        }

        void update(){
            tickAllBoundRecs();
        }

        skittInstalledText(){
            push(&window.scriptPointers);
            sprite.push(&window.textPointers);
        }
};

class startingInstall : public gameObject{
    public:

        text sprite = text(trect(0,0,700,100), "startingInstallText", "text", 1, "starting install...",  {255,255,255}, Sans, window.ren);

    
        void start(){
            bindRec(&sprite.sprite_rec);
            gameObjectRec = trect(window.CENTERX-1000, window.CENTERY+100,0,0);
        }

        void update(){
            tickAllBoundRecs();
        }

        startingInstall(){
            push(&window.scriptPointers);
            sprite.push(&window.textPointers);
        }
};

class installDoneText : public gameObject{
    public:

        text sprite = text(trect(0,0,700,100), "installDoneText", "text", 1, "DONE!",  {255,255,255}, Sans, window.ren);

    
        void start(){
            bindRec(&sprite.sprite_rec);
            gameObjectRec = trect(window.CENTERX-1000, window.CENTERY+100,0,0);
        }

        void update(){
            tickAllBoundRecs();
        }

        installDoneText(){
            push(&window.scriptPointers);
            sprite.push(&window.textPointers);
        }
};

void startInstall(){

    const char* dir = "C:/skitt";

    struct stat sb;

    if (stat(dir, &sb) == 0){
        new skittInstalledText();
        debuger.writeLine("(!!)-- skitt has been installed", ERRORS);
    }
    else{
        system("..\\install.bat");
        new installDoneText();
        //std::terminate();
    }
}

class install : public gameObject{

    public:


        void click(int st, int t, button * self){
            if(st == 1){

                // startInstall();
                // window.camx += window.width;
                int targetPos = 1000;
                double speed = -20;
                taskHandler.addTask(new task(
                    "lerp", 
                    [this,speed]() mutable { 
                        window.camx += speed;
                        speed += 0.5;
                    }, 
                    [this](){
                        
                    }, 
                    [this,targetPos]() -> bool{
                        std::cout << "camx: " << window.camx << "\n";
                        if(window.camx < targetPos){
                            return false;
                        }
                        else{
                            window.camx = targetPos;
                            startInstall();
                            return true;
                        }
                    }));
            }
        }
        
        button installButton = button([this](int st, int t, button * self){click(st, t, self);}, trect(0,0,50,50), trect(0,0,100,100), "installButton", "button", 2, gAssets.apple);

        void start(){
            gameObjectRec = trect(window.CENTERX,window.CENTERY+200,0,0);
            bindRec(&installButton.buttonRec);
            bindRec(&installButton.buttonSprite.sprite_rec);
        }

        void update(){
            tickAllBoundRecs();
        }

        install(){
            name = "installButton";
            pushGameObject(&window.gameObjectPointers);
            push(&window.scriptPointers);
            installButton.push(&window.buttonPointers, &window.spritePointers);
        }

};





std::vector<sprite*> sprites = {};
std::vector<text*> texts = {};

std::vector<button*> buttons = {};


void closed(){
    
}

void start(){

    window.width = 1000;
    window.height = 600;
    window.open_window("some window");

    
    window.load_assets();
    if (TTF_Init() < 0) {
	    std::cout << "Error initializing SDL_ttf: " << TTF_GetError() << "\n";
    }
    Sans = TTF_OpenFont("fonts/static/OpenSans-Medium.ttf", 24);


    // buttons.push_back(new button([](int st, button * self){if(st == 1){std::cout<<"hello\n";}else if(st == 2){std::cout<<"hover\n";}}, trect(window.CENTERX,window.CENTERY,25,25), trect(window.CENTERX, window.CENTERY, 100,100), "button", "button", 1, gAssets.apple));
    // buttons[buttons.size()-1]->push(&window.buttonPointers, &window.spritePointers);

    // texts.push_back(new text(trect(window.CENTERX,window.CENTERY,300,100), "text", "ui", 1, "hello, this a screen saver",  {255,255,255}, Sans, window.ren));
    // texts[texts.size()-1]->push(&window.textPointers);

    // sprites.push_back(new sprite(trect(window.CENTERX, window.CENTERY,40,40), "ball", "gameObject", 1, gAssets.apple));
    // sprites[sprites.size()-1]->push(&window.spritePointers);

    //new gamePlayManger();

    new leakText();

    new installDirText();

    new install();


    debuger.debug = true;
    debuger.level = ERRORS;

    bool isWindowOpen = true;

    while (isWindowOpen){
        
        // clear

        window.renClear();

        // window exit?

        SDL_PollEvent(&event);
        isWindowOpen = window.checkIfUserExitThenExit(event, &closed);

        // handle events

        window.handleEvents(event);

        taskHandler.updateAll();



        // draw
        window.setBg(100,200,100);
        
        window.renderAllSprites();

        //show
        window.show();
    }

    std::cout << " exited!\n";

}



int main(int argc, char ** argv){
    start();
    return 0;
}