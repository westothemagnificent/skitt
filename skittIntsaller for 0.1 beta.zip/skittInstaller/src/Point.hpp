#include <iostream>
#include <cmath>

#pragma once

class point{
  public:
    double x;
    double y;
    ~point(){
      // std::cout << "im dead :(\n";
    }
    point(double x, double y){
      point::x = x;
      point::y = y;

    }
    void add(point p){
      point::x += p.x;
      point::y += p.y;
    }
    void sub(point p){
      point::x -= p.x;
      point::y -= p.y;
    }
    void muit(point p){
      point::x *= p.x;
      point::y *= p.y;
    }
    void div(point p){
      point::x /= p.x;
      point::y /= p.y;
    }
    double distance(point p){
      return std::sqrt((point::y - p.y) * (point::y - p.y) + (point::x - p.x) * (point::x - p.x));
    }
    double distancesquared(point p){
      return ((point::y - p.y) * (point::y - p.y) + (point::x - p.x) * (point::x - p.x));
    }
    double length(){
      return std::sqrt((point::y - 0) * (point::y - 0) + (point::x - 0) * (point::x - 0));
    }
    void nom(){
      double len = length();
        y /= len;
        x /= len;
    }
    void lerp(point p, double t){
      x = (p.x - x) * t + x;
      y = (p.y - y) * t + y;
    }
    void print(){
      std::cout << "x, " << x << "y, " << y << "\n\n";
    }
    void rotate(double radians, double rotationCenterX, double rotationCenterY) {
        double ox = x - rotationCenterX;
        double oy = y - rotationCenterY;
        x = (cos(radians) * ox) + (-sin(radians) * oy) + rotationCenterX;
        y = (sin(radians) * ox) + ( cos(radians) * oy) + rotationCenterY;
    }
  private:
  //linus NO
    // double x;
    // double y;     
    
};